# KING Detection v1.2
Android source project. Upload the **contents** of this ZIP to the root of the GitHub repository. GitHub Actions builds a debug APK.

## Functionality
- Simulated startup calibration (visual animation, not actual calibration)
- Live step trace based on step detector, with accelerometer fallback
- Compass-based approximate relative heading where sensors are available
- BLE scan of advertising nearby devices (permission required)
- Start/pause/reset and clear status labels

## Limitations
The walking trace is an approximate visualization, not accurate indoor positioning. Nearby phones are not necessarily discoverable via Bluetooth; a negative scan does not establish that no phone is present. The app does not claim to detect all concealed electronics.
