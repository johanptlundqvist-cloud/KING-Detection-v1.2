package se.king.detection

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.*
import android.hardware.*
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.*
import android.widget.*
import java.util.Locale
import kotlin.math.*

class MainActivity : Activity(), SensorEventListener {
    private lateinit var sensors: SensorManager
    private var stepSensor: Sensor? = null
    private var accelerometer: Sensor? = null
    private var magnetometer: Sensor? = null
    private var gravity = FloatArray(3)
    private var magnetic = FloatArray(3)
    private var haveGravity = false
    private var haveMagnetic = false
    private var heading = 0f
    private var tracking = false
    private var scanning = false
    private var lastFallbackStep = 0L
    private var aboveThreshold = false
    private var filteredMagnitude = 0f
    private var steps = 0
    private val points = mutableListOf(Pair(0f,0f))
    private val devices = linkedMapOf<String,Int>()
    private var callback: ScanCallback? = null
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var stepLabel: TextView
    private lateinit var scanLabel: TextView
    private lateinit var radar: RadarView
    private lateinit var startButton: Button
    private lateinit var scanButton: Button
    private var calibrated = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(3,9,20)
        window.navigationBarColor = Color.rgb(3,9,20)
        sensors = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        stepSensor = sensors.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR)
        accelerometer = sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        magnetometer = sensors.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        showSplash()
    }
    private fun label(text: String, size: Float = 15f): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(Color.rgb(210,235,249))
        gravity = android.view.Gravity.CENTER; setPadding(12,12,12,12)
    }
    private fun button(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text; setTextColor(Color.WHITE)
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(19,70,99)))
        setOnClickListener { action() }
    }
    private fun showSplash() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = android.view.Gravity.CENTER
            setPadding(28,28,28,28); setBackgroundColor(Color.rgb(3,9,20))
        }
        root.addView(label("KING",52f))
        root.addView(label("D E T E C T I O N",23f))
        root.addView(label("SYSTEM INITIALIZATION",14f))
        val progress = ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply {
            max=100; progress=0; isIndeterminate=false
        }
        root.addView(progress,LinearLayout.LayoutParams(-1,18))
        val caption=label("Simulerad kalibrering • 0 %")
        root.addView(caption)
        root.addView(label("Visuell uppstartssekvens – ingen sensorkalibrering utförs.",12f))
        val go=button("ÖPPNA DETEKTOR  ›") { showDashboard() }.apply { isEnabled=false }
        root.addView(go)
        setContentView(root)
        var n=0
        val tick=object:Runnable {
            override fun run() {
                if (isFinishing || calibrated) return
                n=(n+4).coerceAtMost(100)
                progress.progress=n
                caption.text="Simulerad kalibrering • $n %"
                if(n<100) handler.postDelayed(this,65)
                else { calibrated=true; caption.text="SYSTEM READY"; go.isEnabled=true }
            }
        }
        handler.post(tick)
    }
    private fun showDashboard() {
        val root=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(12,8,12,8)
            setBackgroundColor(Color.rgb(3,9,20))
        }
        root.addView(label("KING  /  DETECTION",25f))
        status=label("REDO • Starta gångspårning",13f); root.addView(status)
        radar=RadarView(this)
        root.addView(radar,LinearLayout.LayoutParams(-1,0,1f))
        stepLabel=label("STEG  0     •     SPÅR  0 m",16f); root.addView(stepLabel)
        scanLabel=label("BLUETOOTH  •  Ej aktiv",13f); root.addView(scanLabel)
        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        startButton=button("▶ START") { toggleTracking() }
        row.addView(startButton,LinearLayout.LayoutParams(0,-2,1f))
        row.addView(button("↺ NOLLSTÄLL") { resetTrace() },LinearLayout.LayoutParams(0,-2,1f))
        root.addView(row)
        scanButton=button("⌁ SÖK BLUETOOTH") { toggleScan() }
        root.addView(scanButton)
        root.addView(label("Spåret är relativt och ungefärligt. BLE hittar bara enheter som annonserar.",11f))
        setContentView(root)
        refresh()
    }
    private fun toggleTracking() {
        if (!tracking) {
            if (Build.VERSION.SDK_INT>=29 && checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION)!=PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.ACTIVITY_RECOGNITION),100)
                return
            }
            tracking=true
            if (stepSensor!=null) sensors.registerListener(this,stepSensor,SensorManager.SENSOR_DELAY_NORMAL)
            else accelerometer?.let { sensors.registerListener(this,it,SensorManager.SENSOR_DELAY_GAME) }
            // Heading from available sensors; no GPS or false indoor location claims.
            accelerometer?.let { sensors.registerListener(this,it,SensorManager.SENSOR_DELAY_UI) }
            magnetometer?.let { sensors.registerListener(this,it,SensorManager.SENSOR_DELAY_UI) }
        } else { tracking=false; sensors.unregisterListener(this) }
        refresh()
    }
    private fun resetTrace() {
        steps=0; points.clear(); points.add(Pair(0f,0f))
        devices.clear(); radar.invalidate(); refresh()
    }
    private fun refresh() {
        if (!::status.isInitialized) return
        val source=if(stepSensor!=null) "stegsensor" else if(accelerometer!=null) "accelerometer" else "ingen stegsensor"
        status.text=if(tracking) "SPÅRNING AKTIV • $source" else "PAUSAD / REDO • $source"
        startButton.text=if(tracking) "Ⅱ PAUSA" else "▶ START"
        stepLabel.text="STEG  $steps     •     UPPSKATTAT  ${String.format(Locale.US,"%.1f",steps*0.7f)} m"
        scanLabel.text=if(scanning) "BLE SKANNAR • ${devices.size} annonserande enheter" else "BLE AV • ${devices.size} senast sedda"
        scanButton.text=if(scanning) "■ STOPPA BLUETOOTH" else "⌁ SÖK BLUETOOTH"
        radar.invalidate()
    }
    private fun addStep() {
        if(!tracking) return
        steps++
        val rad=Math.toRadians(heading.toDouble())
        val last=points.last()
        points.add(Pair(last.first+sin(rad).toFloat()*0.7f,last.second-cos(rad).toFloat()*0.7f))
        refresh()
    }
    override fun onSensorChanged(event: SensorEvent) {
        when(event.sensor.type) {
            Sensor.TYPE_STEP_DETECTOR -> if(tracking) addStep()
            Sensor.TYPE_ACCELEROMETER -> {
                for(i in 0..2) gravity[i]=event.values[i]
                haveGravity=true
                if(stepSensor==null && tracking) {
                    val mag=sqrt(event.values.fold(0.0) { sum, v -> sum + v.toDouble()*v.toDouble() }).toFloat()
                    filteredMagnitude=filteredMagnitude*0.85f+(mag-9.81f)*0.15f
                    val now=android.os.SystemClock.elapsedRealtime()
                    if(filteredMagnitude>0.65f && !aboveThreshold && now-lastFallbackStep>340) {
                        addStep(); lastFallbackStep=now; aboveThreshold=true
                    }
                    if(filteredMagnitude<0.1f) aboveThreshold=false
                }
            }
            Sensor.TYPE_MAGNETIC_FIELD -> {
                for(i in 0..2) magnetic[i]=event.values[i]
                haveMagnetic=true
            }
        }
        if(haveGravity && haveMagnetic) {
            val r=FloatArray(9); val orientation=FloatArray(3)
            if(SensorManager.getRotationMatrix(r,null,gravity,magnetic)) {
                SensorManager.getOrientation(r,orientation)
                heading=Math.toDegrees(orientation[0].toDouble()).toFloat()
            }
        }
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    private fun toggleScan() {
        if(scanning) { stopScan(); refresh(); return }
        if(Build.VERSION.SDK_INT in 26..30 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),101); return
        }
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)!=PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_SCAN),101); return
        }
        val manager=getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter=manager.adapter
        if(adapter==null || !adapter.isEnabled) {
            Toast.makeText(this,"Aktivera Bluetooth i telefonens inställningar.",Toast.LENGTH_LONG).show();return
        }
        val scanner=adapter.bluetoothLeScanner
        if(scanner==null) { Toast.makeText(this,"BLE-skanning stöds inte just nu.",Toast.LENGTH_LONG).show();return }
        callback=object:ScanCallback() {
            override fun onScanResult(callbackType:Int,result:ScanResult) {
                val id=result.device.address
                devices[id]=result.rssi
                refresh()
            }
            override fun onScanFailed(errorCode:Int) {
                scanning=false; scanLabel.text="BLE-fel: $errorCode"; refresh()
            }
        }
        try { scanner.startScan(callback); scanning=true; refresh() }
        catch(e:SecurityException) { Toast.makeText(this,"Bluetooth-behörighet saknas.",Toast.LENGTH_LONG).show() }
        catch(e:Exception) { Toast.makeText(this,"Kunde inte starta BLE: ${e.message}",Toast.LENGTH_LONG).show() }
    }
    private fun stopScan() {
        val cb=callback ?: return
        try {
            val manager=getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
            manager.adapter?.bluetoothLeScanner?.stopScan(cb)
        } catch(_:Exception) {}
        callback=null; scanning=false
    }
    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray) {
        super.onRequestPermissionsResult(requestCode,permissions,grantResults)
        if(grantResults.firstOrNull()==PackageManager.PERMISSION_GRANTED) {
            if(requestCode==100) toggleTracking()
            if(requestCode==101) toggleScan()
        } else Toast.makeText(this,"Behörighet nekades. Funktionen startades inte.",Toast.LENGTH_LONG).show()
    }
    override fun onPause() {
        super.onPause()
        if(::radar.isInitialized) {
            if(tracking) { tracking=false; sensors.unregisterListener(this) }
            stopScan(); refresh()
        }
    }
    override fun onDestroy() { sensors.unregisterListener(this); stopScan(); handler.removeCallbacksAndMessages(null); super.onDestroy() }

    inner class RadarView(context:Context): View(context) {
        private val paint=Paint(3)
        override fun onDraw(canvas:Canvas) {
            super.onDraw(canvas)
            val w=width.toFloat();val h=height.toFloat()
            val cx=w/2;val cy=h/2
            canvas.drawColor(Color.rgb(4,16,30))
            paint.style=Paint.Style.STROKE; paint.strokeWidth=2f
            paint.color=Color.rgb(20,72,91)
            val radius=min(w,h)*0.43f
            for(i in 1..4) canvas.drawCircle(cx,cy,radius*i/4,paint)
            canvas.drawLine(cx-radius,cy,cx+radius,cy,paint)
            canvas.drawLine(cx,cy-radius,cx,cy+radius,paint)
            paint.color=Color.rgb(35,245,193);paint.strokeWidth=4f
            if(points.size>1) {
                val xs=points.map{it.first};val ys=points.map{it.second}
                val minX=xs.minOrNull()?:0f;val maxX=xs.maxOrNull()?:0f
                val minY=ys.minOrNull()?:0f;val maxY=ys.maxOrNull()?:0f
                val span=max(maxX-minX,maxY-minY).coerceAtLeast(8f)
                val scale=radius*1.7f/span
                val centerX=(maxX+minX)/2;val centerY=(maxY+minY)/2
                val path=Path()
                points.forEachIndexed { i,pt ->
                    val x=cx+(pt.first-centerX)*scale
                    val y=cy+(pt.second-centerY)*scale
                    if(i==0) path.moveTo(x,y) else path.lineTo(x,y)
                }
                canvas.drawPath(path,paint)
                val last=points.last()
                paint.style=Paint.Style.FILL
                canvas.drawCircle(cx+(last.first-centerX)*scale,cy+(last.second-centerY)*scale,8f,paint)
            } else {
                paint.style=Paint.Style.FILL;canvas.drawCircle(cx,cy,7f,paint)
            }
            paint.color=Color.rgb(167,218,230);paint.textSize=27f;paint.style=Paint.Style.FILL
            canvas.drawText("RELATIVT GÅNGSPÅR",16f,38f,paint)
            paint.textSize=20f
            canvas.drawText("N ↑  •  ${devices.size} BLE",16f,h-18f,paint)
        }
    }
}
