plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "se.king.detection"
    compileSdk = 35
    defaultConfig {
        applicationId = "se.king.detection"
        minSdk = 26
        targetSdk = 35
        versionCode = 12
        versionName = "1.2"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
