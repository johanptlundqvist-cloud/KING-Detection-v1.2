# KING Detection v1.2 — Android source project

## Build in GitHub Actions
Upload **this ZIP** to the root of a GitHub repository with `.github/workflows/build-apk.yml` also present as a **real file** (not inside the ZIP). Alternatively extract the ZIP and upload all files, preserving directories. GitHub Actions > Build KING Detection APK > Run workflow. Download the APK from the run's **Artifacts** section.

## Features
- KING radar-inspired launcher artwork, dark dashboard with animated radar view
- Simulated calibration animation (clearly labeled, not a real sensor calibration)
- Live magnetic-field magnitude in microtesla, deviation from session baseline
- BLE scan counts unique advertising Bluetooth devices (requires Bluetooth and permissions)
- Walk tracking draws an estimated path from hardware step-detector events
- Session log, reset controls, simple privacy-first local storage
- Android 8+ / Java 17 / Android Gradle Plugin 8.5.2

## Important limitations
A hidden phone is **not** reliably detectable using the magnetometer or Bluetooth alone. Bluetooth scanning only detects devices that advertise. Walk track is a sensor-based sketch, not indoor positioning. Heading uses the rotation-vector sensor when available; step length is assumed and heading can drift. Some devices do not have a step detector. No claims of reliable exam-room screening.

## Verification status
Source and workflow generated; **not compiled or device-tested in this environment**. GitHub Actions is the required first build test. Static source review is not proof of runtime correctness.
