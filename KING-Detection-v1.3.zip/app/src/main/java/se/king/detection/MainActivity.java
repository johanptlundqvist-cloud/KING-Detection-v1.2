package se.king.detection;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.hardware.*;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.view.*;
import android.widget.*;
import java.util.*;
import android.content.SharedPreferences;
import android.hardware.SensorManager;
import android.graphics.drawable.GradientDrawable;
import android.text.format.DateFormat;

public class MainActivity extends Activity implements SensorEventListener {
    SensorManager sensors;
    Sensor magnet, steps, accelerometer, rotation;
    LinearLayout panel;
    TextView status, magText, stepText, bleText;
    TrackView track;
    int count=0, bleCount=0;
    long scanStarted=0;
    float totalMeters=0;
    TextView details;
    ArrayList<String> logEntries=new ArrayList<>();
    SharedPreferences prefs;
    float baseline=0, magnetic=0, heading=0;
    float[] gravity=new float[3], geomagnetic=new float[3];
    boolean haveGravity=false, haveMagnetic=false;
    boolean tracking=false, scanning=false;
    BluetoothLeScanner scanner;
    ScanCallback callback;
    final Set<String> devices=new HashSet<>();
    final int cyan=Color.rgb(50,226,255), bg=Color.rgb(8,16,30);
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences("king_detection",MODE_PRIVATE);
        sensors=(SensorManager)getSystemService(SENSOR_SERVICE);
        magnet=sensors.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        steps=sensors.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);
        accelerometer=sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        rotation=sensors.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        splash();
    }
    TextView label(String text,int size){
        TextView t=new TextView(this);t.setText(text);t.setTextSize(size);
        t.setTextColor(cyan);t.setPadding(18,16,18,16);return t;
    }
    void splash(){
        LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setGravity(Gravity.CENTER);
        l.setBackgroundColor(bg);setContentView(l);
        TextView title=label("KING\nDETECTION",38);title.setGravity(Gravity.CENTER);l.addView(title);
        TextView sub=label("INITIALIZING SENSOR INTERFACE\nVISUAL CALIBRATION SIMULATION",16);sub.setGravity(Gravity.CENTER);l.addView(sub);
        ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);l.addView(bar,new LinearLayout.LayoutParams(-1,35));
        Handler h=new Handler(Looper.getMainLooper());
        for(int i=1;i<=20;i++){final int v=i;h.postDelayed(()->bar.setProgress(v*5),i*85);}
        h.postDelayed(()->{ if(!isFinishing()) dashboard(); },1900);
    }
    void dashboard(){
        ScrollView scroll=new ScrollView(this);panel=new LinearLayout(this);panel.setPadding(20,20,20,20);
        panel.setOrientation(1);panel.setBackgroundColor(bg);scroll.addView(panel);setContentView(scroll);
        panel.addView(label("KING  /  DETECTION",30));
        panel.addView(label("◉  SIGNAL INTELLIGENCE  /  CLASSROOM MODE",14));
        panel.addView(label("FIELD SCANNER     •     V1.2",13));
        status=label("READY • Sensors are not phone detectors",13);panel.addView(status);
        magText=label("MAGNETIC FIELD: -- µT",19);panel.addView(magText);
        stepText=label("STEPS: 0",18);panel.addView(stepText);
        bleText=label("BLE DEVICES: 0",18);panel.addView(bleText);
        details=label("Estimated distance: 0 m  •  Scan idle",14);panel.addView(details);
        panel.addView(label("RADAR / SENSOR TELEMETRY",14));
        panel.addView(new RadarView(this),new LinearLayout.LayoutParams(-1,460));
        addButton("◎  START / STOP BLE SEARCH",()->toggleScan());
        addButton("⌁  START / STOP WALK TRACK",()->toggleTrack());
        addButton("↺  RESET WALK TRACK",()->{count=0;totalMeters=0;track.reset();stepText.setText("STEPS: 0");details.setText("Estimated distance: 0 m");log("Walk track reset");});
        addButton("⊙  RE-CALIBRATE DISPLAY",()->{stopScan();sensors.unregisterListener(this);panel=null;splash();});
        addButton("▤  VIEW SESSION LOG",()->showLog());
        addButton("ⓘ  SENSOR LIMITATIONS",()->new AlertDialog.Builder(this).setTitle("What this app can detect").setMessage("BLE scanning finds only devices actively advertising over Bluetooth. A phone can be present without appearing. Magnetic readings are not a reliable way to detect a hidden phone. Walk traces are estimates based on sensors and drift over time. Do not treat a missing signal as proof that no phone is present.").setPositiveButton("OK",null).show());
        track=new TrackView(this);panel.addView(track,new LinearLayout.LayoutParams(-1,650));
        panel.addView(label("LIVE WALK TRACE  •  estimated / not GPS",14));
        panel.addView(label("Walk trace uses step events and heading. BLE discovers only advertising devices; magnetic readings cannot reliably identify phones. A blank scan does not mean a phone is absent.",13));
        startSensors();
        requestPermissions();
    }
    void addButton(String s,Runnable action){
        Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(20,74,103)));
        panel.addView(b,new LinearLayout.LayoutParams(-1,115));b.setOnClickListener(v->action.run());
    }
    void requestPermissions(){
        if(Build.VERSION.SDK_INT>=31){
            ArrayList<String> req=new ArrayList<>();
            for(String p:new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.ACTIVITY_RECOGNITION,Manifest.permission.ACCESS_FINE_LOCATION})
                if(checkSelfPermission(p)!=PackageManager.PERMISSION_GRANTED)req.add(p);
            if(!req.isEmpty())requestPermissions(req.toArray(new String[0]),100);
        }else if(Build.VERSION.SDK_INT>=29){
            ArrayList<String> req=new ArrayList<>();
            for(String p:new String[]{Manifest.permission.ACTIVITY_RECOGNITION,Manifest.permission.ACCESS_FINE_LOCATION})
                if(checkSelfPermission(p)!=PackageManager.PERMISSION_GRANTED)req.add(p);
            if(!req.isEmpty())requestPermissions(req.toArray(new String[0]),100);
        }
    }
    void startSensors(){
        if(magnet!=null)sensors.registerListener(this,magnet,SensorManager.SENSOR_DELAY_UI);
        if(accelerometer!=null)sensors.registerListener(this,accelerometer,SensorManager.SENSOR_DELAY_UI);
        if(steps!=null)sensors.registerListener(this,steps,SensorManager.SENSOR_DELAY_NORMAL);
        if(rotation!=null)sensors.registerListener(this,rotation,SensorManager.SENSOR_DELAY_UI);
        if(steps==null && status!=null)status.setText("STEP DETECTOR UNAVAILABLE • Walk tracking limited");
    }
    void toggleTrack(){
        if(steps==null){status.setText("No hardware step detector on this phone");return;}
        tracking=!tracking;
        if(tracking)log("Walk tracking started");else log("Walk tracking paused");
        status.setText(tracking?"WALK TRACKING ACTIVE":"WALK TRACKING PAUSED");
    }
    void toggleScan(){
        if(scanning){stopScan();return;}
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions();status.setText("Bluetooth permission required");return;
        }
        BluetoothManager bm=(BluetoothManager)getSystemService(BLUETOOTH_SERVICE);
        BluetoothAdapter adapter=bm==null?null:bm.getAdapter();
        if(adapter==null || !adapter.isEnabled()){status.setText("Enable Bluetooth first");return;}
        scanner=adapter.getBluetoothLeScanner();
        if(scanner==null){status.setText("BLE scanner unavailable");return;}
        devices.clear();bleCount=0;bleText.setText("BLE DEVICES: 0");
        callback=new ScanCallback(){
            @Override public void onScanResult(int type,ScanResult result){
                String address=result.getDevice().getAddress();
                if(devices.add(address)){bleCount=devices.size();runOnUiThread(()->bleText.setText("BLE DEVICES: "+bleCount));}
            }
            @Override public void onScanFailed(int error){runOnUiThread(()->status.setText("BLE scan failed: "+error));}
        };
        try{scanner.startScan(callback);scanning=true;scanStarted=System.currentTimeMillis();log("BLE scan started");status.setText("BLE SCANNING ACTIVE");}
        catch(SecurityException ex){status.setText("Bluetooth permission denied");}
    }
    void stopScan(){
        if(scanner!=null&&callback!=null)try{scanner.stopScan(callback);}catch(SecurityException ignored){}
        scanning=false;log("BLE scan stopped: "+bleCount+" advertising devices");status.setText("BLE SCAN STOPPED");
    }
    void log(String entry){
        String item=DateFormat.format("yyyy-MM-dd HH:mm:ss",System.currentTimeMillis())+"  "+entry;
        logEntries.add(0,item);
        if(logEntries.size()>100)logEntries.remove(logEntries.size()-1);
        prefs.edit().putString("last_log",android.text.TextUtils.join("\n",logEntries)).apply();
    }
    void showLog(){
        String saved=prefs.getString("last_log","No session events yet");
        new AlertDialog.Builder(this).setTitle("SESSION LOG").setMessage(saved)
          .setPositiveButton("CLOSE",null)
          .setNeutralButton("CLEAR",(d,w)->{logEntries.clear();prefs.edit().remove("last_log").apply();}).show();
    }
    @Override public void onSensorChanged(SensorEvent e){
        if(e.sensor.getType()==Sensor.TYPE_MAGNETIC_FIELD){
            System.arraycopy(e.values,0,geomagnetic,0,3);haveMagnetic=true;
            float x=e.values[0],y=e.values[1],z=e.values[2];
            magnetic=(float)Math.sqrt(x*x+y*y+z*z);
            if(baseline==0)baseline=magnetic;
            if(magText!=null)magText.setText(String.format(java.util.Locale.US,"MAGNETIC FIELD: %.1f µT  |  Δ %.1f",magnetic,Math.abs(magnetic-baseline)));
            updateHeading();
        }else if(e.sensor.getType()==Sensor.TYPE_ACCELEROMETER){
            System.arraycopy(e.values,0,gravity,0,3);haveGravity=true;updateHeading();
        }else if(e.sensor.getType()==Sensor.TYPE_STEP_DETECTOR && tracking && track!=null){
            count++;totalMeters=count*0.7f;stepText.setText("STEPS: "+count);details.setText(String.format(java.util.Locale.US,"Estimated distance: %.1f m  •  BLE: %d",totalMeters,bleCount));track.step(heading);
        }else if(e.sensor.getType()==Sensor.TYPE_ROTATION_VECTOR){
            float[] matrix=new float[9];float[] orientation=new float[3];
            SensorManager.getRotationMatrixFromVector(matrix,e.values);
            SensorManager.getOrientation(matrix,orientation);
            heading=orientation[0];
        }
    }
    void updateHeading(){
        if(rotation!=null || !haveGravity || !haveMagnetic)return;
        float[] r=new float[9],i=new float[9],o=new float[3];
        if(SensorManager.getRotationMatrix(r,i,gravity,geomagnetic)){
            SensorManager.getOrientation(r,o);heading=o[0];
        }
    }
    @Override public void onAccuracyChanged(Sensor s,int a){}
    @Override protected void onPause(){super.onPause();sensors.unregisterListener(this);if(scanning)stopScan();}
    @Override protected void onResume(){super.onResume();if(panel!=null)startSensors();}

    class RadarView extends View {
        Paint p=new Paint(3);
        long start=System.currentTimeMillis();
        RadarView(Context c){super(c);}
        @Override protected void onDraw(Canvas canvas){
            super.onDraw(canvas);
            int w=getWidth(),h=getHeight();
            canvas.drawColor(Color.rgb(10,26,42));
            float cx=w/2f,cy=h/2f,r=Math.min(w,h)*.42f;
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);
            p.setColor(Color.rgb(23,87,106));
            for(int j=1;j<=4;j++)canvas.drawCircle(cx,cy,r*j/4,p);
            canvas.drawLine(cx-r,cy,cx+r,cy,p);
            canvas.drawLine(cx,cy-r,cx,cy+r,p);
            float a=((System.currentTimeMillis()-start)%5000)/5000f*360;
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(55,0,220,240));
            canvas.drawArc(cx-r,cy-r,cx+r,cy+r,a-45,45,true,p);
            p.setColor(cyan);p.setStrokeWidth(4);
            p.setStyle(Paint.Style.STROKE);
            double theta=Math.toRadians(a);
            canvas.drawLine(cx,cy,cx+(float)Math.cos(theta)*r,cy+(float)Math.sin(theta)*r,p);
            p.setStyle(Paint.Style.FILL);canvas.drawCircle(cx,cy,7,p);
            postInvalidateDelayed(50);
        }
    }
    class TrackView extends View{
        Paint paint=new Paint(3);ArrayList<PointF> points=new ArrayList<>();
        TrackView(Context c){super(c);reset();}
        void reset(){points.clear();points.add(new PointF(0,0));invalidate();}
        void step(float direction){
            PointF p=points.get(points.size()-1);
            points.add(new PointF(p.x+(float)Math.sin(direction)*14,p.y-(float)Math.cos(direction)*14));invalidate();
        }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);c.drawColor(Color.rgb(11,30,47));
            paint.setColor(Color.rgb(27,61,77));paint.setStrokeWidth(1);
            for(int x=0;x<getWidth();x+=40)c.drawLine(x,0,x,getHeight(),paint);
            for(int y=0;y<getHeight();y+=40)c.drawLine(0,y,getWidth(),y,paint);
            if(points.isEmpty())return;
            PointF end=points.get(points.size()-1);
            c.save();c.translate(getWidth()/2f-end.x,getHeight()/2f-end.y);
            paint.setColor(cyan);paint.setStrokeWidth(5);paint.setStyle(Paint.Style.STROKE);
            Path path=new Path();path.moveTo(points.get(0).x,points.get(0).y);
            for(PointF p:points)path.lineTo(p.x,p.y);
            c.drawPath(path,paint);paint.setStyle(Paint.Style.FILL);
            c.drawCircle(end.x,end.y,10,paint);c.restore();
        }
    }
}
